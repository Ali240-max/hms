/**
 * Document numbers: dated, daily, and never colliding.
 */
const B = process.env.API_BASE ?? 'http://127.0.0.1:4000/api'
const tok = {}
const login=async(u,p)=>(await (await fetch(B+'/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:u,password:p})})).json()).token
const q=async(path,as,o={})=>{const r=await fetch(B+path,{...o,headers:{'content-type':'application/json',authorization:'Bearer '+tok[as],...(o.headers||{})}});const t=await r.text();let b;try{b=JSON.parse(t)}catch{b=t};return{status:r.status,body:b}}
let pass=0,fail=0
const ok=(n,c,x='')=>{c?(pass++,console.log('  ok   '+n)):(fail++,console.log('  FAIL '+n+(x?' — '+x:'')))}
for (const [k,u,p] of [['mc','main-counter','1234'],['lab','lab','1234'],['ph','pharmacy','1234'],['doc','dr.yasir','1234']]) tok[k]=await login(u,p)

const d = new Date()
const DAY = String(d.getFullYear()).slice(2) +
  String(d.getMonth()+1).padStart(2,'0') + String(d.getDate()).padStart(2,'0')
console.log(`\n— today's segment is ${DAY} —`)

console.log('\n— a visit —')
let r = await q('/patients','mc',{method:'POST',body:JSON.stringify({ name:'Numbering Test', phone:'0300-9998887' })})
const pt = r.body
const docs = (await q('/doctors','mc')).body
r = await q('/visits','mc',{method:'POST',body:JSON.stringify({ patientId: pt.id, doctorId: docs[0].id })})
const visit = r.body
const visitNo = visit.visitNo ?? visit.visit_no
ok('a visit is numbered VIS-<date>-V<seq>',
  new RegExp(`^VIS-${DAY}-V\\d{5}$`).test(visitNo), visitNo)

console.log('\n— a counter bill —')
const draft = (await q(`/counter/draft/visit/${visit.id}`,'mc')).body
r = await q('/counter/bills','mc',{method:'POST',body:JSON.stringify({
  kind:'consultation', visitId: visit.id, payMethod:'cash',
  tenderedPaisa: Number(draft.totalPaisa) })})
ok('a consultation bill is INV-<date>-C<seq>',
  new RegExp(`^INV-${DAY}-C\\d{5}$`).test(r.body.bill?.bill_no ?? r.body.bill_no ?? ''),
  r.body.bill?.bill_no ?? r.body.bill_no)

console.log('\n— a chit —')
const svcs = (await q('/services','mc')).body.filter(s=>s.category==='lab').slice(0,1)
r = await q('/counter/direct','mc',{method:'POST',body:JSON.stringify({
  patientId: pt.id, serviceIds: svcs.map(s=>s.id) })})
const direct = r.body
ok('a walk-in visit is VIS-<date>-D<seq>',
  new RegExp(`^VIS-${DAY}-D\\d{5}$`).test(direct.visit.visit_no), direct.visit.visit_no)
ok('a chit is CHIT-<date>-T<seq>',
  new RegExp(`^CHIT-${DAY}-T\\d{5}$`).test(direct.chits[0].chit_no), direct.chits[0].chit_no)

r = await q('/counter/bills','mc',{method:'POST',body:JSON.stringify({
  kind:'chit', chitId: direct.chits[0].id, payMethod:'cash',
  tenderedPaisa: Number(direct.chits[0].total_paisa) })})
ok('a chit bill is INV-<date>-D<seq>',
  new RegExp(`^INV-${DAY}-D\\d{5}$`).test(r.body.bill?.bill_no ?? r.body.bill_no ?? ''),
  r.body.bill?.bill_no ?? r.body.bill_no)

console.log('\n— a lab report —')
const work = (await q('/lab/queue?status=all','lab')).body
  .filter(x=>x.visit_id===direct.visit.id && x.lab_status==='pending')
if (work.length) {
  r = await q('/lab/collect','lab',{method:'POST',body:JSON.stringify({ serviceOrderId: work[0].service_order_id })})
  ok('a lab report is LAB-<date>-L<seq>',
    new RegExp(`^LAB-${DAY}-L\\d{5}$`).test(r.body.report_no), r.body.report_no)
} else ok('a lab report is LAB-<date>-L<seq>', false, 'no paid lab work created')

console.log('\n— a pharmacy sale —')
const inv = (await q('/pharmacy/inventory','ph')).body.filter(p=>p.in_stock >= (p.pack_size||1))
r = await q('/pharmacy/sales','ph',{method:'POST',body:JSON.stringify({
  lines:[{ productId: inv[0].id, qty:1, soldAs: inv[0].allow_loose ? 'unit' : 'pack' }],
  payMethod:'cash', paidPaisa: 100000000, customerName:'Numbering' })})
const sale = r.body.sale ?? r.body
ok('a sale is PH-<date>-S<seq>',
  new RegExp(`^PH-${DAY}-S\\d{5}$`).test(sale.invoiceNo ?? sale.invoice_no ?? ''),
  sale.invoiceNo ?? sale.invoice_no)

console.log('\n— the sequence runs per day, not forever —')
{
  // Two documents of the same kind, issued back to back.
  const a = await q('/counter/direct','mc',{method:'POST',body:JSON.stringify({
    patientId: pt.id, serviceIds: svcs.map(s=>s.id) })})
  const b = await q('/counter/direct','mc',{method:'POST',body:JSON.stringify({
    patientId: pt.id, serviceIds: svcs.map(s=>s.id) })})
  const na = Number(a.body.chits[0].chit_no.split('-').pop().replace('T',''))
  const nb = Number(b.body.chits[0].chit_no.split('-').pop().replace('T',''))
  ok('consecutive documents increment by one', nb === na + 1, `${na} then ${nb}`)
  ok('both carry the date for today',
    a.body.chits[0].chit_no.includes(DAY) && b.body.chits[0].chit_no.includes(DAY))
  ok('the sequence is five digits, so 99,999 a day',
  /\d{5}$/.test(b.body.chits[0].chit_no), b.body.chits[0].chit_no)
}

console.log('\n— two tills at once cannot collide —')
{
  const made = await Promise.all(Array.from({ length: 8 }, () =>
    q('/counter/direct','mc',{method:'POST',body:JSON.stringify({
      patientId: pt.id, serviceIds: svcs.map(s=>s.id) })})))
  const nos = made.map(x => x.body.chits?.[0]?.chit_no).filter(Boolean)
  ok('eight simultaneous chits all succeeded', nos.length === 8, `${nos.length}/8`)
  ok('and every number is different', new Set(nos).size === nos.length,
    nos.length - new Set(nos).size + ' duplicates')
}

console.log('\n— an MRN says who and when, and is still unique —')
{
  /*
   * SU17-26092026-04: initials, age, the date, and a per-day sequence.
   *
   * The initials and age are there so a clerk holding a slip can tell whether
   * it is the right patient before reading the number out. They are not
   * unique on their own — two 17-year-olds with the same initials on one
   * morning is ordinary in an OPD — which is what the last pair is for.
   */
  ok('it carries initials, age, date and a sequence',
    /^[A-Z]{2}\d{2}-\d{8}-\d{2,}$/.test(pt.mrn), pt.mrn)

  const day = new Date()
  const stamp = String(day.getDate()).padStart(2, '0') +
    String(day.getMonth() + 1).padStart(2, '0') + String(day.getFullYear())
  ok('the date is today', pt.mrn.split('-')[1] === stamp, pt.mrn)

  const twin = (await q('/patients','mc',{method:'POST',body:JSON.stringify({
    name: 'Numbering Twin', ageYears: 30 })})).body
  const twin2 = (await q('/patients','mc',{method:'POST',body:JSON.stringify({
    name: 'Numbering Twin', ageYears: 30 })})).body
  ok('two identical patients on one day get different numbers',
    twin.mrn !== twin2.mrn, `${twin.mrn} vs ${twin2.mrn}`)
  ok('and they differ only in the sequence',
    twin.mrn.split('-').slice(0,2).join('-') === twin2.mrn.split('-').slice(0,2).join('-'))

  const single = (await q('/patients','mc',{method:'POST',body:JSON.stringify({
    name: 'Ayesha', ageYears: null })})).body
  ok('a one-word name still gives two letters and an age of 00',
    /^AY00-/.test(single.mrn), single.mrn)
}

console.log('\n— a reset does not leave numbers behind —')
{
  /*
   * The counters table is emptied by a demo reset, so every table holding a
   * number issued FROM it has to be emptied with it.
   *
   * Three tables added after that list was written were not on it — stock
   * audits, stock adjustments and purchase orders. A reset left AUD-261009-01
   * on the shelf while the counter went back to zero, and the next count
   * sheet anybody tried to save was refused with a duplicate key. A reset
   * that leaves the database unable to do a normal thing is worse than no
   * reset.
   *
   * Read from the source rather than performed, because running a reset here
   * would wipe the database the rest of these suites are using.
   */
  const { readFileSync } = await import('node:fs')
  const demo = readFileSync('src/server/services/demo.ts', 'utf8')
  const truncate = (demo.match(/TRUNCATE[\s\S]*?RESTART IDENTITY CASCADE/) ?? [''])[0]
  ok('the reset truncates the counters', /\bcounters\b/.test(truncate))
  for (const t of ['stock_audits', 'stock_adjustments', 'purchase_orders']) {
    ok(`and ${t}, which carries a counter-issued number`,
      new RegExp(`\\b${t}\\b`).test(truncate))
  }
}

console.log(`\n${pass} passed, ${fail} failed\n`)
process.exit(fail?1:0)
