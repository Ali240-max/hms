Hospital Management System — offline bundle

1. Install Node.js and PostgreSQL.
2. Create the database:  createdb -U postgres hms
3. Create a .env file beside this one:
     DATABASE_URL=postgres://postgres:PASSWORD@localhost:5432/hms
     PORT=4000
4. Double-click START.bat
5. Open http://localhost:4000 and create the first administrator.

Migrations run by themselves on first start.
