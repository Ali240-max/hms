@echo off
rem Starts the hospital server. Keep this window open.
cd /d "%~dp0"
node dist\server\index.js
pause
